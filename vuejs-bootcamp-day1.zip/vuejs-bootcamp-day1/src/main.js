import { createApp } from "vue";
// import RootApp from "./RootApp.vue";
import Main from "./Main.vue";
import "./assets/app.css";

createApp(Main).mount("#app");